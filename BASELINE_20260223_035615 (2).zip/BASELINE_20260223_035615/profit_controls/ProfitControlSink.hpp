#pragma once

namespace chimera {

class ProfitControlSink {
public:
    virtual ~ProfitControlSink() = default;
};

}
